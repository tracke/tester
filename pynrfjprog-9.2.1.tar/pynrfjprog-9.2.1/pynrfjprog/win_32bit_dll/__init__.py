# 32bit DLL for Windows.

